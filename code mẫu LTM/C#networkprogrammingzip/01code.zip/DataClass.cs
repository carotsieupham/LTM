class DataClass
{
    private int a;
    private int b;

    public DataClass(int x, int y)
    {
	a = x;
	b = y;
    }

    public int addem()
    {
	return a + b;
    }
}